#include <utility>
#pragma once
#define HOST_JUDGE __host_judge_2076030

namespace HOST_JUDGE{
	const int MAXN = 8;
	const int MAX = MAXN + 2 + 1;
	// 1 for black, 2 for white
	extern int bk, wt, nowType;
	extern int board[MAX][MAX];
	extern int tempBoard[3][25][MAX][MAX];
	void initGame();
	void printBoard();
	int stepScore(int type, int x, int y);
	bool avaiPlayer(int type);
	void makeStep(int type, int x, int y);
	int finalWinner();
	void clearBoard(int num);
	void forkBoard(int num);
	void copyBoard(int toNum, int fromNum);
	int stepBoard(int num, int type, int x, int y);
	void moveBoard(int num, int type, int x, int y);
	int getChess(int num, int x, int y);
	std::pair<int,int> nowScore(int num);
};

int pointFromStep(int x, int y);
void clearTempBoard(int num);
void forkBoardToTemp(int num);
void copyTempBoard(int toNum, int fromNum);
int stepOnTempBoard(int num, int type, int x, int y);
void moveOnTempBoard(int num, int type, int x, int y);
int getChessOnTempBoard(int num, int x, int y);
std::pair<int,int> nowScoreOnTempBoard(int num);

#undef HOST_JUDGE
