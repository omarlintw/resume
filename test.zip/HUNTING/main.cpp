#include "utilities.h"
#include "judge.h"
#include "player.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <utility>
#include <algorithm>
#define PLAYER1 JudgeSpace::AI
#define PLAYER2 PlayerSpace::AI
using namespace std;
using namespace __host_judge_2076030;

/*
Host Judge Functions
void initGame();
void printBoard();
int stepScore(int type, int x, int y);
*/

int runGame();

int main(){
	initGame();
	int winner = runGame();
	printBoard();
	if(winner == 0) puts("Draw");
	else printf("The winner is : \"%s\"\n", winner == 1 ? "black" : "white");
	return 0;
}

int runGame(){
	bool ttype = false;
	PLAYER1 p1;
	p1.initialize(1);
	PLAYER2 p2;
	p2.initialize(2);
	while( (ttype = avaiPlayer(1)) || avaiPlayer(2)){
		if(ttype){
			nowType = 1;
			pair<int,int> nowStep = p1.nextStep();
			int tmp = stepScore(nowType, nowStep.first, nowStep.second);
			if(tmp <= 0) return 2;
			makeStep(nowType, nowStep.first, nowStep.second);
			p2.opponentStep(nowStep.first, nowStep.second);
		}
		printBoard();
		if(avaiPlayer(2)){
			nowType = 2;
			pair<int,int> nowStep = p2.nextStep();
			int tmp = stepScore(nowType, nowStep.first, nowStep.second);
			if(tmp <= 0) return 1;
			makeStep(nowType, nowStep.first, nowStep.second);
			p1.opponentStep(nowStep.first, nowStep.second);
		}
		printBoard();
	}
	return finalWinner();
}

