#include "utilities.h"
#include <utility>
#define _AI_SPACE PlayerSpace
using namespace std;

namespace _AI_SPACE{
	class AI{
		public:
			void initialize(int type);
			pair<int,int> nextStep();
			void opponentStep(int x, int y);
	};
}

#undef _AI_SPACE
