#include <utility>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <tuple>
#include "player.h"
#define _AI_SPACE PlayerSpace

namespace _AI_SPACE{
	int chess;
	void AI::initialize(int type){
		chess = type;
	}
	bool check(){
		int counter=0;
		forkBoardToTemp(11);
		if(getChessOnTempBoard(11, 1, 1)>0)
			++counter;
		if(getChessOnTempBoard(11, 1, 8)>0)
			++counter;
		if(getChessOnTempBoard(11, 8, 1)>0)
			++counter;
		if(getChessOnTempBoard(11, 8, 8)>0)
			++counter;
		if(counter>1);
			return false;
		return true;
	}
	tuple<int, int, int> dfs1(int time, int chess, int x, int y){
		tuple<int, int, int> MAX;
		get<2>(MAX) = -100;
		if(time==5){
			int counter=0;
			if(((x==1)||(x==8))&&((y==1)||(y==8)))
				counter = counter-6;
			if((x==1)||(x==8)||(y==1)||(y==8))
				counter = counter-3;
			for(int i=1;i<9;i++){
				for(int j=1;j<9;j++){
					if(stepOnTempBoard(time,chess,i,j)>0)
						++counter;
				}
			}
			return make_tuple(x, y, counter);
		}
		if(!time%2){
			int value=0;
			for(int i=1;i<9;i++){
				for(int j=1;j<9;j++){
					if(stepOnTempBoard(time,chess,i,j)>0){
						copyTempBoard(time+1, time);
						moveOnTempBoard(time+1, chess, i, j);
						tuple<int, int, int> temp = dfs1(time+1, 3-chess, i, j);
						value += get<2>(temp);
					}		
				}
			}
			return make_tuple(x, y, value);
		}
		else{
			for(int i=1;i<9;i++){
				for(int j=1;j<9;j++){
					if(stepOnTempBoard(time,chess,i,j)>0){
						copyTempBoard(time+1, time);
						moveOnTempBoard(time+1, chess, i, j);
						tuple<int, int, int> temp = dfs1(time+1, 3-chess, i, j);
						if(get<2>(MAX)<get<2>(temp))
							MAX = temp;
					}		
				}
			}
			return MAX;
		}
	} 
	int cvalue(int dep){
		int myType = chess;
		pair<int,int> tmp = nowScoreOnTempBoard(dep);
		int tt = 0;
		for(int i = 1 ; i <= 8 ; i++){
			for(int j = 1 ; j <= 8 ; j++){
				tt += stepOnTempBoard(dep, chess, i, j) -
					stepOnTempBoard(dep, 3-chess, i, j);
			}
		}
		if(myType == 1)
			return tmp.first - tmp.second + tt;
		else
			return tmp.second - tmp.first + tt;
	}
	tuple<int,int,int> dfs2(int dep, int type, int x, int y){
		if(dep == 4){
			return make_tuple(x,y,cvalue(dep));
		}
		bool gt = false;
		int tx1 = -1, ty1 = -1, tv1 = -100000;
		int tx2 = -1, ty2 = -1, tv2 = 100000;
		for(int i = 1 ; i <= 8 ; i++){
			for(int j = 1 ; j <= 8 ; j++){
				if(stepOnTempBoard(dep, type, i, j) > 0){
					copyTempBoard(dep+1, dep);
					moveOnTempBoard(dep+1, type, i, j);
					tuple<int,int,int> tmp = dfs2(dep+1, 3-type, x, y);
					gt = true;
					if(get<2>(tmp) > tv1){
						tx1 = i;
						ty1 = j;
						tv1 = get<2>(tmp);
					}
					if(get<2>(tmp) < tv2){
						tx2 = i;
						ty2 = j;
						tv2 = get<2>(tmp);
					}	
				}
			}
		}
		if(!gt){
			return make_tuple(x,y,cvalue(dep));
		}
		if(type == 1) return make_tuple(tx1,ty1,tv1);
		return make_tuple(tx2,ty2,tv2);
	}
	pair<int,int> AI::nextStep(){
		forkBoardToTemp(1);
		if(check()){
			tuple<int, int, int> temp = dfs1(1, chess, -1, -1);
			return make_pair(get<0>(temp), get<1>(temp));
		}
		else{
			tuple<int, int, int> temp = dfs2(1, chess, -1, -1);
			return make_pair(get<0>(temp), get<1>(temp));			
		}
	}

	void AI::opponentStep(int x, int y){
	}

}

#undef _AI_SPACE

/*
 * Functions Provided By The Judge
 * int pointFromStep(int x, int y);
 *     呼叫這個Function可以獲得當下你如果下棋步(x,y)能夠得到的分數（包含所下的那一步），如果所下棋步
 * 超過棋盤，則會得到回傳值-1。如果那一步不能下，則會得到回傳值0。
 *
 * Judge端提供一個打譜介面，詳細操作如下：
 *
 * 每位玩家擁有20個操作盤面（編號1~20），初始皆為空。
 *
 * void clearTempBoard(int num);
 *     呼叫這個Function可以清空編號為num的盤面。
 * void forkBoardToTemp(int num);
 *     呼叫這個Function可以把當前盤面複製到編號為num的盤面。
 * void copyTempBoard(int toNum, int fromNum);
 *     呼叫這個Function可以把編號為fromNum的盤面複製到編號為toNum的盤面。
 * int stepOnTempBoard(int num, int type, int x, int y);
 *     呼叫這個Function可以得到：在編號為num的盤面上，執type棋者，當下下在(x,y)所能得到的分數。
 * void moveOnTempBoard(int num, int type, int x, int y);
 *     呼叫這個Function可以在編號為num的盤面上，在(x,y)位置上放上type棋。（如果該位置原本有棋，會先
 * 將該格清空，視為該格原本沒棋。
 * int getChessOnTempBoard(int num, int x, int y);
 *     呼叫這個Function可以得到編號為num的盤面上，目前(x,y)位置是什麼顏色的棋。1為黑棋、2為白棋，若
 * 為0代表那一格目前沒有棋。
 * std::pair<int,int> nowScoreOnTempBoard(int num);
 *     呼叫這個Function可以得到：當前編號為num的盤面上，兩位玩家比數為何。first是黑棋的分數，second
 * 是白棋的分數。
 *
 * 若以上打譜函數得到回傳值-1，則有可能發生以下情況：
 * 1. num/toNum/fromNum不在[1,20]
 * 2. (x,y)超出棋盤
 */
