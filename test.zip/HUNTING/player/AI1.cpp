#include <utility>
#include <tuple>
#include "player.h"
#define _AI_SPACE PlayerSpace

namespace _AI_SPACE{
	int mytype, optype;
    
    tuple<int, int, int> dfs(int time, int type, int x, int y){
        if(time==20)
            return make_tuple(x, y, value(time));
        bool flag = true;
        if(time%2==1){
            tuple<int, int, int> predict = make_tuple(x, y, -1000);
            for(int i=1;i<9;i++){
                for(int j=1;j<9;j++){
                    if(stepOnTempBoard(time, type, i, j)>0){
                        flag = false;
                        copyTempBoard(time+1, time);
                        moveOnTempBoard(time+1, type, i, j);
                        tuple<int, int, int> temp = dfs(time+1, 3-type, i, j);
                        if(get<2>(predict) < get<2>(temp))
                            predict = temp;
                    }
                }
            }
        }
        else{
            tuple<int, int, int> predict = make_tuple(x, y, 1000);
            for(int i=0;i<9;i++){
                for(int j=1;j<9;j++){
                    if(stepOnTempBoard(time, type, i, j)>0){
                        flag = false;
                        copyTempBoard(time+1, time);
                        moveOnTempBoard(time+1, type, i, j);
                        tuple<int, int, int> temp = dfs(time+1, 3-type, i, j);
                        if(get<2>(predict) > get<2>(temp))
                            predict = temp;
                    }
                }
            }
        }
        if(flag)
            return make_tuple(x, y, value(time));
        return predict;
    }
    
    int value(int time){
        pair<int, int> temp = nowScoreOnTempBoard(time);
        if(mytype==2)
            return temp.first - temp.second;
        return temp.second - temp.first;
    }
    
	void AI::initialize(int type){
		mytype = type;
		optype = 3 - type;
		/* 
		 * 遊戲開始時，Judge端會先呼叫這個Function。
		 * 當type=1時執黑棋（先手），type=2時執白棋（後手）。
		 */
	}

	pair<int,int> AI::nextStep(){
        forkBoardToTemp(1);
        tuple<int, int, int> temp = dfs(1, mytype, -1, -1);
        return make_pair(get<0>(temp), get<1>(temp));
		/* 
		 * 當輪到你的棋步時，Judge端會呼叫這個Function。
		 * 請用std::make_pair(int x,int y)回報你要下的棋步座標。
		 */
	}

	void AI::opponentStep(int x, int y){
		/* 
		 * 對方每次下棋時，Judge端都會用這個Function來通知你對方的棋步。
		 */
	}

}

#undef _AI_SPACE

/*
 * Functions Provided By The Judge
 * int pointFromStep(int x, int y);
 *     呼叫這個Function可以獲得當下你如果下棋步(x,y)能夠得到的分數（包含所下的那一步），如果所下棋步
 * 超過棋盤，則會得到回傳值-1。如果那一步不能下，則會得到回傳值0。
 * 
 * Judge端提供一個打譜介面，詳細操作如下： 
 * 
 * 每位玩家擁有20個操作盤面（編號1~20），初始皆為空。
 * 
 * void clearTempBoard(int num);
 *     呼叫這個Function可以清空編號為num的盤面。
 * void forkBoardToTemp(int num);
 *     呼叫這個Function可以把當前盤面複製到編號為num的盤面。
 * void copyTempBoard(int toNum, int fromNum);
 *     呼叫這個Function可以把編號為fromNum的盤面複製到編號為toNum的盤面。
 * int stepOnTempBoard(int num, int type, int x, int y);
 *     呼叫這個Function可以得到：在編號為num的盤面上，執type棋者，當下下在(x,y)所能得到的分數。
 * void moveOnTempBoard(int num, int type, int x, int y);
 *     呼叫這個Function可以在編號為num的盤面上，在(x,y)位置上放上type棋。（如果該位置原本有棋，會先
 * 將該格清空，視為該格原本沒棋。
 * int getChessOnTempBoard(int num, int x, int y);
 *     呼叫這個Function可以得到編號為num的盤面上，目前(x,y)位置是什麼顏色的棋。1為黑棋、2為白棋，若
 * 為0代表那一格目前沒有棋。
 * std::pair<int,int> nowScoreOnTempBoard(int num);
 *     呼叫這個Function可以得到：當前編號為num的盤面上，兩位玩家比數為何。first是黑棋的分數，second
 * 是白棋的分數。
 * 
 * 若以上打譜函數得到回傳值-1，則有可能發生以下情況：
 * 1. num/toNum/fromNum不在[1,20]
 * 2. (x,y)超出棋盤
 */
