#include "player.h"
#include <cstdio>
#include <cstring>
#include <utility>
#include <ctime>
#include <cstdlib>
#include <random>
#include <algorithm>
#define _AI_SPACE PlayerSpace
using namespace std;

namespace _AI_SPACE{

	const int MAX = 10 + 2;
	int rec[MAX][MAX];
	int pos[MAX*MAX];
	int myType, opType;
	//pointFromStep(int x, int y)

	void AI::initialize(int type){
		memset(rec, 0, sizeof(rec));
		for(int i = 0 ; i < 64 ; i++) pos[i] = i;
		rec[4][5] = rec[5][4] = 1;
		rec[4][4] = rec[5][5] = 2;
		myType = type;
		opType = 3 - type;
	}

	pair<int,int> AI::nextStep(){
		shuffle(pos, pos+64, default_random_engine(time(0)));
		int now = 0;
		pair<int,int> t;
		for(int k = 0 ; k < 64 ; k++){
			int tpos = pos[k];
			int i = tpos/8+1, j = tpos%8+1;
			int tt;
			if( (tt = pointFromStep(i,j)) > now){
				now = tt;
				t = make_pair(i,j);
			}
		}
		puts("");
		return t;
	}

	void AI::opponentStep(int x, int y){
		rec[x][y] = opType;
	}

}

#undef _AI_SPACE
