#include "utilities.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <utility>
#include <algorithm>
#define HOST_JUDGE __host_judge_2076030
using namespace std;

namespace HOST_JUDGE{
	int bk, wt, nowType;
	int board[MAX][MAX];
	int tempBoard[3][25][MAX][MAX];
};

void HOST_JUDGE::initGame(){
	nowType = 1;
	bk = wt = 2;
	memset(board, -1, sizeof(board));
	memset(tempBoard, -1, sizeof(tempBoard));
	for(int i = 1 ; i <= MAXN ; i++){
		for(int j = 1 ; j <= MAXN ; j++){
			board[i][j] = 0;
		}
	}
	// black
	board[4][5] = board[5][4] = 1;
	// white
	board[4][4] = board[5][5] = 2;
}

void HOST_JUDGE::printBoard(){
	puts("Print Board Status :");
	for(int i = 1 ; i <= MAXN ; i++){
		for(int j = 1 ; j <= MAXN ; j++){
			if(board[i][j] == 0) putchar('O');
			else if(board[i][j] == 1) putchar('B');
			else putchar('W');
		}
		puts("");
	}
	puts("--------------------");
}

int HOST_JUDGE::stepScore(int type, int x, int y){
	if(type != 1 && type != 2) return -1;
	if(x < 1 || x > MAXN) return -1;
	if(y < 1 || y > MAXN) return -1;
	if(board[x][y] != 0) return -1;
	int dx[8] = { 1, 0,-1, 0, 1, 1,-1,-1};
	int dy[8] = { 0, 1, 0,-1, 1,-1, 1,-1};
	int score = 0;
	for(int dir = 0 ; dir < 8 ; dir++){
		int cnt = 0;
		for(int nowx = x + dx[dir], nowy = y + dy[dir] ;
				nowx >= 1 && nowx <= MAXN &&
				nowy >= 1 && nowy <= MAXN && board[nowx][nowy] != 0 ;
				nowx += dx[dir], nowy += dy[dir]){
			if(board[nowx][nowy] == type){
				score += cnt;
				break;
			}
			cnt++;
		}
	}
	if(score) score++;
	return score;
}

bool HOST_JUDGE::avaiPlayer(int type){
	for(int i = 1 ; i <= MAXN ; i++){
		for(int j = 1 ; j <= MAXN ; j++){
			if(stepScore(type, i, j) > 0) return true;
		}
	}
	return false;
}

void HOST_JUDGE::makeStep(int type, int x, int y){
	int dx[8] = { 1, 0,-1, 0, 1, 1,-1,-1};
	int dy[8] = { 0, 1, 0,-1, 1,-1, 1,-1};
	int sp = 1, am = 0;
	board[x][y] = type;
	for(int dir = 0 ; dir < 8 ; dir++){
		int cnt = 0;
		for(int nowx = x + dx[dir], nowy = y + dy[dir] ;
				nowx >= 1 && nowx <= MAXN &&
				nowy >= 1 && nowy <= MAXN && board[nowx][nowy] != 0 ;
				nowx += dx[dir], nowy += dy[dir]){
			if(board[nowx][nowy] == type){
				if(cnt){
					for(int tx = x + dx[dir], ty = y + dy[dir] ;
							tx != nowx || ty != nowy ;
							tx += dx[dir], ty += dy[dir]){
						board[tx][ty] = type;
					}
				}
				sp += cnt;
				am -= cnt;
				break;
			}
			cnt++;
		}
	}
	if(type == 1) bk += sp, wt += am;
	else bk += am, wt += sp;
}

int HOST_JUDGE::finalWinner(){
	printf("Final Standing : black %d , whites %d\n", bk, wt);
	if(bk==wt) return 0;
	return bk > wt ? 1 : 2;
}

void HOST_JUDGE::clearBoard(int num){
	memset(tempBoard[nowType][num], -1, sizeof(tempBoard[nowType][num]));
	for(int i = 1 ; i <= MAXN ; i++){
		for(int j = 1 ; j <= MAXN ; j++){
			tempBoard[nowType][num][i][j] = 0;
		}
	}
}

void HOST_JUDGE::forkBoard(int num){
	for(int i = 0 ; i <= MAXN+1 ; i++){
		for(int j = 0 ; j <= MAXN+1 ; j++){
			tempBoard[nowType][num][i][j] = board[i][j];
		}
	}
}

void HOST_JUDGE::copyBoard(int toNum, int fromNum){
	for(int i = 0 ; i <= MAXN + 1 ; i++){
		for(int j = 0 ; j <= MAXN + 1 ; j++){
			tempBoard[nowType][toNum][i][j] = tempBoard[nowType][fromNum][i][j];
		}
	}
}

int HOST_JUDGE::stepBoard(int num, int type, int x, int y){
	if(tempBoard[nowType][num][x][y] != 0) return -1;
	int dx[8] = { 1, 0,-1, 0, 1, 1,-1,-1};
	int dy[8] = { 0, 1, 0,-1, 1,-1, 1,-1};
	int score = 0;
	for(int dir = 0 ; dir < 8 ; dir++){
		int cnt = 0;
		for(int nowx = x + dx[dir], nowy = y + dy[dir] ;
				nowx >= 1 && nowx <= MAXN &&
				nowy >= 1 && nowy <= MAXN && tempBoard[nowType][num][nowx][nowy] != 0 ;
				nowx += dx[dir], nowy += dy[dir]){
			if(tempBoard[nowType][num][nowx][nowy] == type){
				score += cnt;
				break;
			}
			cnt++;
		}
	}
	if(score) score++;
	return score;

}

void HOST_JUDGE::moveBoard(int num, int type, int x, int y){
	tempBoard[nowType][num][x][y] = type;
	int dx[8] = { 1, 0,-1, 0, 1, 1,-1,-1};
	int dy[8] = { 0, 1, 0,-1, 1,-1, 1,-1};
	for(int dir = 0 ; dir < 8 ; dir++){
		int cnt = 0;
		for(int nowx = x + dx[dir], nowy = y + dy[dir] ;
				nowx >= 1 && nowx <= MAXN &&
				nowy >= 1 && nowy <= MAXN && tempBoard[nowType][num][nowx][nowy] != 0 ;
				nowx += dx[dir], nowy += dy[dir]){
			if(tempBoard[nowType][num][nowx][nowy] == type){
				if(cnt){
					for(int tx = x + dx[dir], ty = y + dy[dir] ;
							tx != nowx || ty != nowy ;
							tx += dx[dir], ty += dy[dir]){
						tempBoard[nowType][num][tx][ty] = type;
					}
				}
				break;
			}
			cnt++;
		}
	}
}

int HOST_JUDGE::getChess(int num, int x, int y){
	return tempBoard[nowType][num][x][y];
}

pair<int,int> HOST_JUDGE::nowScore(int num){
	int p1 = 0, p2 = 0;
	for(int i = 1 ; i <= MAXN ; i++){
		for(int j = 1 ; j <= MAXN ; j++){
			if(tempBoard[nowType][num][i][j] == 1) p1++;
			else if(tempBoard[nowType][num][i][j] == 2) p2++;
		}
	}
	return make_pair(p1, p2);
}

int pointFromStep(int x, int y){
	return HOST_JUDGE::stepScore(HOST_JUDGE::nowType, x, y);
}

void clearTempBoard(int num){
	if(num < 1 || num > 20) return;
	HOST_JUDGE::clearBoard(num);	
}

void forkBoardToTemp(int num){
	if(num < 1 || num > 20) return;
	HOST_JUDGE::forkBoard(num);
}

void copyTempBoard(int toNum, int fromNum){
	if(toNum < 1 || toNum > 20) return;
	if(fromNum < 1 || fromNum > 20) return;
	HOST_JUDGE::copyBoard(toNum, fromNum);
}

int stepOnTempBoard(int num, int type, int x, int y){
	if(num < 1 || num > 20) return -1;
	if(type != 1 && type != 2) return -1;
	if(x < 1 || x > HOST_JUDGE::MAXN) return -1;
	if(y < 1 || y > HOST_JUDGE::MAXN) return -1;
	return HOST_JUDGE::stepBoard(num,type,x,y);
}

void moveOnTempBoard(int num, int type, int x, int y){
	if(num < 1 || num > 20) return;
	if(type != 1 && type != 2) return;
	if(x < 1 || x > HOST_JUDGE::MAXN) return;
	if(y < 1 || y > HOST_JUDGE::MAXN) return;
	HOST_JUDGE::moveBoard(num, type, x, y);
}

int getChessOnTempBoard(int num, int x, int y){
	if(num < 1 || num > 20) return -1;
	if(x < 1 || x > HOST_JUDGE::MAXN) return -1;
	if(y < 1 || y > HOST_JUDGE::MAXN) return -1;
	return HOST_JUDGE::getChess(num, x, y);	
}

pair<int,int> nowScoreOnTempBoard(int num){
	if(num < 1 || num > 20) return make_pair(-1,-1);
	return HOST_JUDGE::nowScore(num);
}

#undef HOST_JUDGE
