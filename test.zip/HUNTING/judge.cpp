#include "judge.h"
#include <utility>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <tuple>
#include <ctime>
#define _AI_SPACE JudgeSpace
using namespace std;

namespace _AI_SPACE{

	//pointFromStep(int x, int y)
	// 1 is me
	int myType, opType;

	void AI::initialize(int type){
		srand(time(0));
		myType = type;
		opType = 3-type;
	}

	int cvalue(int dep){
		pair<int,int> tmp = nowScoreOnTempBoard(dep);
		int tt = 0;
		for(int i = 1 ; i <= 8 ; i++){
			for(int j = 1 ; j <= 8 ; j++){
				tt += stepOnTempBoard(dep, myType, i, j) -
					stepOnTempBoard(dep, opType, i, j);
			}
		}
		if(myType == 1)
			return tmp.first - tmp.second + tt;
		else
			return tmp.second - tmp.first + tt;
	}

	tuple<int,int,int> dfs(int dep, int type, int x, int y){
		if(dep == 4){
			return make_tuple(x,y,cvalue(dep));
		}
		bool gt = false;
		int tx1 = -1, ty1 = -1, tv1 = -100000;
		int tx2 = -1, ty2 = -1, tv2 = 100000;
		for(int i = 1 ; i <= 8 ; i++){
			for(int j = 1 ; j <= 8 ; j++){
				if(stepOnTempBoard(dep, type, i, j) > 0){
					copyTempBoard(dep+1, dep);
					moveOnTempBoard(dep+1, type, i, j);
					tuple<int,int,int> tmp = dfs(dep+1, 3-type, x, y);
					gt = true;
					if(get<2>(tmp) > tv1){
						tx1 = i;
						ty1 = j;
						tv1 = get<2>(tmp);
					}
					if(get<2>(tmp) < tv2){
						tx2 = i;
						ty2 = j;
						tv2 = get<2>(tmp);
					}	
				}
			}
		}
		if(!gt){
			return make_tuple(x,y,cvalue(dep));
		}
		if(type == 1) return make_tuple(tx1,ty1,tv1);
		return make_tuple(tx2,ty2,tv2);
	}

	pair<int,int> AI::nextStep(){
		forkBoardToTemp(1);
		tuple<int,int,int> tmp = dfs(1, myType, -1, -1);
		return make_pair(get<0>(tmp), get<1>(tmp));
	}

	void AI::opponentStep(int x, int y){
	}

}

#undef _AI_SPACE
